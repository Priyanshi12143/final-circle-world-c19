var bubbles = [];

function setup() {
  createCanvas(600,400);
  
  bubble1 = new Bubble();
  bubble2 = new Bubble();
  bubble3 = new Bubble();
 bubble4 = new Bubble();
   bubble5 = new Bubble();
   bubble6 = new Bubble();
   bubble7 = new Bubble();
   bubble8 = new Bubble();
}

function draw() {
  background("black");
  bubble1.move();
  bubble3.move();
  bubble5.move();
   bubble7.move();
   bubble8.move();
  
  bubble1.display();
  bubble2.display();
  bubble3.display();
   bubble4.display();
   bubble5.display();
   bubble6.display();
   bubble7.display();
   bubble8.display();
}

    